const fs= require('fs');
const path = require('path');
const filePath = path.resolve(__dirname, "../data/users.json");
const readData=()=>{
    const userData=JSON.parse(fs.readFileSync(filePath,"utf-8"));
    return userData;
}
const writeData=(data)=>{
    fs.writeFileSync(filePath,data);
}
const getUser=(req,res)=>{
   const userData=readData();
   res.status(200).json({
    success:true,
    data : userData
   })
}
const getUserId=(req,res)=>{
  const id=parseInt(req.params.id);
   const userData=readData();
  const user=userData.find((user)=>user.id === id);
  res.status(200).json({
    success:true,
    data:user
  })
}
const addUser=(req,res)=>{
    const obj=req.body;
     const userData=readData();
     const newData=[...userData,obj];
     writeData(JSON.stringify(newData));
     res.status(200).json({
        success:true,
        message:"user added successfully"
     })
}
const updateUser=(req,res,next)=>{
     const id=parseInt(req.params.id);
    const obj=req.body;
    const replaceUser=userData.find((user)=> user.id === id);
    if(replaceUser===undefined)
    {
          return next(new Error("User not found"));
    }
    const index=userData.indexOf(replaceUser);
       if (index === -1) {
           return next(new Error("User not found"));
    }
    userData[index]=obj;
    writeData(JSON.stringify(userData));
    res.status(200).json({
        message:"Updated user",
        data:userData
})
}
const deleteUser=(req,res)=>{
    const id=parseInt(req.params.id);
   const userData=readData();
  const user=userData.filter((user)=>user.id !== id);
  writeData(JSON.stringify(user));
  res.status(200).json({
    success:true,
    data:user
  })
}
module.exports={
    getUser,
    getUserId,
    addUser,updateUser,
    deleteUser
}