const fs= require('fs');
const path = require('path');
   const filePath = path.resolve(__dirname, "../data/orders.json");
const readData=()=>{

      const orderData=JSON.parse(fs.readFileSync(filePath,"utf-8"));
    return orderData;
}
const writeData=(data)=>{
    fs.writeFileSync(filePath,data);
}
const getOrder=(req,res)=>{
   const orderData=readData();
   res.status(200).json({
    success:true,
    data : orderData
   })
}
const getOrderById=(req,res)=>{
  const id=parseInt(req.params.id);
   const orderData=readData();
  const order=orderData.find((order)=>order.id === id);
  res.status(200).json({
    success:true,
    data:order
  })
}
const addOrder=(req,res)=>{
    const obj=req.body;
     const orderData=readData();
     orderData.push(obj);
     writeData(JSON.stringify(orderData));
     res.status(200).json({
        success:true,
        message:"order added successfully"
     })
}

const deleteOrder=(req,res)=>{
    const id=parseInt(req.params.id);
   const orderData=readData();
  const order=orderData.filter((order)=>order.id !== id);
  writeData(JSON.stringify(order));
  res.status(200).json({
    success:true,
    data:order
  })
}
module.exports={
    getOrder,
    getOrderById,
    addOrder,
    deleteOrder
}