const fs= require('fs');
const path = require('path');
  const filePath = path.resolve(__dirname, "../data/products.json");
const readData=()=>{
      const productData=JSON.parse(fs.readFileSync(filePath,"utf-8"));
    return productData;
}
const writeData=(data)=>{
    fs.writeFileSync(filePath,data);
}
const getProducts=(req,res)=>{
   const productData=readData();
   res.status(200).json({
    success:true,
    data : productData
   })
}
const getProductById=(req,res)=>{
  const id=parseInt(req.params.id);
   const productData=readData();
  const product=productData.find((product)=>product.id === id);
  res.status(200).json({
    success:true,
    data:product
  })
}
const addProduct=(req,res)=>{
    const obj=req.body;
     const productData=readData();
     productData.push(obj);
     writeData(JSON.stringify(productData));
     res.status(200).json({
        success:true,
        message:"Product added successfully"
     })
}
const updateProduct=(req,res,next)=>{
     const id=parseInt(req.params.id);
    const obj=req.body;
    const replaceProduct=productData.find((p)=> p.id === id);
    if(replaceproduct===undefined)
    {
          return next(new Error("Product not found"));
    }
    const index=productData.indexOf(replaceProduct);
       if (index === -1) {
           return next(new Error("Product not found"));
    }
    productData[index]=obj;
    writeData(JSON.stringify(productData));
    res.status(200).json({
        message:"Updated product",
        data:productData
})
}
const deleteProduct=(req,res)=>{
    const id=parseInt(req.params.id);
   const productData=readData();
  const products=productData.filter((user)=>user.id !== id);
  writeData(Json.stringify(products));
  res.status(200).json({
    success:true,
    data:products
  })
}
module.exports={
    getProducts,
    getProductById,
    addProduct,
    updateProduct,
    deleteProduct
}